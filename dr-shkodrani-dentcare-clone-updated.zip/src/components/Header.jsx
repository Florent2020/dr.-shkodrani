import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Link, NavLink } from 'react-router-dom';
import { FiCalendar, FiMenu, FiPhone, FiX } from 'react-icons/fi';
import logo from '../assets/logo.jpg';
import { clinic } from '../data/siteData';

const HeaderWrap = styled.header`
  position: fixed;
  z-index: 100;
  top: 0;
  left: 0;
  right: 0;
  color: ${({ $scrolled, $open }) => ($scrolled || $open ? '#10263a' : '#fff')};
  background: ${({ $scrolled, $open }) => ($scrolled || $open ? 'rgba(255,255,255,.96)' : 'transparent')};
  box-shadow: ${({ $scrolled }) => ($scrolled ? '0 8px 30px rgba(8,28,48,.08)' : 'none')};
  backdrop-filter: blur(18px);
  transition: .25s ease;
`;
const Inner = styled.div`
  width: min(1120px, calc(100% - 44px));
  margin: 0 auto;
  padding: ${({ $scrolled }) => ($scrolled ? '8px 0' : '14px 0 18px')};
  transition: .25s ease;
`;
const Top = styled.div`
  display: flex;
  justify-content: space-between;
  font-size: .9rem;
  font-weight: 800;
  opacity: .9;
  margin-bottom: 16px;
  span { display: inline-flex; align-items: center; gap: 6px; }
  @media (max-width: 760px) { display: none; }
`;
const Bar = styled.div`display:flex;align-items:center;justify-content:space-between;gap:18px;`;
const Brand = styled(Link)`display:inline-flex;align-items:center;color:inherit;text-decoration:none;min-width:245px;`;
const Logo = styled.img`
  width: 218px;
  max-height: 58px;
  height: auto;
  object-fit: contain;
  display: block;
  filter: ${({ $scrolled, $open }) => ($scrolled || $open ? 'none' : 'drop-shadow(0 3px 8px rgba(0,0,0,.35))')};
  @media (max-width: 520px) { width: 178px; }
`;
const Nav = styled.nav`
  display:flex;align-items:center;gap:12px;
  a{padding:12px 15px;border-radius:13px;color:inherit;opacity:.88;font-weight:800;font-size:.98rem;text-decoration:none;}
  a.active,a:hover{opacity:1;background:${({ $scrolled }) => ($scrolled ? '#eef7fe' : 'rgba(255,255,255,.17)')};color:${({ $scrolled }) => ($scrolled ? '#158bd8' : '#fff')};}
  @media(max-width:900px){
    position:fixed;top:0;left:0;right:0;padding:92px 24px 28px;background:rgba(255,255,255,.98);color:#10263a;display:grid;justify-items:center;gap:8px;box-shadow:0 18px 40px rgba(8,28,48,.12);
    transform:${({ $open }) => ($open ? 'translateY(0)' : 'translateY(-115%)')};opacity:${({ $open }) => ($open ? 1 : 0)};pointer-events:${({ $open }) => ($open ? 'auto' : 'none')};transition:transform .3s ease,opacity .3s ease;
  }
`;
const Book = styled(NavLink)`background:#1d91dd!important;color:#fff!important;padding:15px 24px!important;box-shadow:0 16px 36px rgba(29,145,221,.3);`;
const MenuButton = styled.button`
  display:none;width:44px;height:44px;border:0;border-radius:12px;color:${({ $scrolled, $open }) => ($scrolled || $open ? '#10263a' : '#fff')};background:${({ $scrolled, $open }) => ($scrolled || $open ? '#eef7fe' : 'rgba(255,255,255,.16)')};
  @media(max-width:900px){display:grid;place-items:center;z-index:120;}
`;

function Header(){
  const [open,setOpen]=useState(false);
  const [scrolled,setScrolled]=useState(false);
  useEffect(()=>{const onScroll=()=>setScrolled(window.scrollY>70);onScroll();window.addEventListener('scroll',onScroll);return()=>window.removeEventListener('scroll',onScroll);},[]);
  const close=()=>setOpen(false);
  return <HeaderWrap $scrolled={scrolled} $open={open}><Inner $scrolled={scrolled}>{!scrolled&&<Top><span><FiPhone/> {clinic.phone}</span><span>{clinic.hoursShort}</span></Top>}<Bar><Brand to='/' onClick={close}><Logo src={logo} alt='Klinika Dentare Dr. Shkodrani' $scrolled={scrolled} $open={open}/></Brand><Nav $open={open} $scrolled={scrolled}><NavLink to='/' onClick={close}>Home</NavLink><NavLink to='/about' onClick={close}>About</NavLink><NavLink to='/services' onClick={close}>Services</NavLink><NavLink to='/reviews' onClick={close}>Reviews</NavLink><NavLink to='/faq' onClick={close}>FAQ</NavLink><NavLink to='/contact' onClick={close}>Contact</NavLink><Book to='/book' onClick={close}><FiCalendar/> Book Appointment</Book></Nav><MenuButton onClick={()=>setOpen(!open)} aria-label='Open menu' $scrolled={scrolled} $open={open}>{open?<FiX size={22}/>:<FiMenu size={22}/>}</MenuButton></Bar></Inner></HeaderWrap>;
}
export default Header;
